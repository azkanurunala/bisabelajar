/*
Berikut adalah Escape Sequences di dalam JavaScript:

\0: Karakter NUL
\b: Backspace
\t: Horizontal tab
\n: Newline
\v: Vertical tab
\f: Form feed
\r: Carriage return
\”: Tanda kutip dua (double quote)
\’: Tanda kutip satu (apostrophe atau single quote)
\\: Garis miring backslash
\xXX: Karakter Latin-1 dengan menggunakan dua digit heksa desimal XX
\uXXXX: Karakter Unicode dengan menggunakan empat digit heksa XXXX

string.charAt()
string.charCodeAt()
string.concat()
string.indexOf()
string.lastIndexOf()
string.localeCompare()
string.match()
string.replace()
string.search()
string.slice()
string.split()
string.substr()
string.substring()
string.toLowerCase()
string.toString()
string.toUpperCase()
string.trim()
string.valueOf()

*/


/*var a;
var b,c,d;
var g=12;
var h="saya sedang belajar javascript";

var nilai = "global";
function test(){
	var nilai_lokal = "duniailkom";
	var nilai = "lokal";
	tanpa_var = "no_scope";
	console.log(nilai);

}

console.log(g);
a="saya azka nurun ala";
console.log(a.length);
console.log(a.toUpperCase());
console.log(a.concat(" masjid"));
var x=12;
var y=x.toString();
console.log(x);
console.log(y);
console.log(x+x);
console.log(y+y);
var z=0.556434;
console.log(z.toExponential());
console.log(z.toFixed(2));
console.log(z.toFixed(2));
console.log(z.toFixed(4));
console.log(z.toPrecision(2));

var a= "bajigur";
console.log(a[0]);
console.log(a[1]);
console.log(a[2]);
console.log(a[3]);
console.log(a[4]);
console.log(a[5]);

var hari="jum\'at";
console.log(hari);

var makan=" makan halabala";
console.log(makan.indexOf("mak"));
var c="maghrib";
var d="isya";
console.log(c.localeCompare(d));
console.log(d.localeCompare(c));
var kalimat ="1 tambah 2 sama dengan 3";
var hasil= kalimat.match(/\d+/g);
console.log(hasil);

var gokil="apakabar";
var gokila=gokil.replace(/a/g,"o");
var b="saya azka nurun ala";
console.log(gokila);
console.log(gokila.search("obo"));
console.log(gokila.slice(2,-1));
console.log(gokila.slice(2,4));
console.log(b.split(" "));
console.log(b.split("a"));
var d="    hahah   hahshdhahdh hhhahahah        hahah      ";
console.log(d.trim());

var t="true";
var f="false";

var angka=123444;

var a=7;
var b="7";
console.log(a===b);*/









<!DOCTYPE html>
<html lang="en">
<?php include ('layout/head.php') ?>


<body id="tryout">
    <?php include ('layout/navbar.php') ?>
    <?php include ('pages/tryout/layout/headerHalf.php') ?>
    <!--?php include ('pages/about/layout/tabSwitch.php') ?-->
    <!--?php include ('layout/header.php') ?-->
    <!--div class="tab tab-content">
		
	</div-->
	<?php include('layout/quote.php'); ?>


	<?php include('layout/footer.php') ?>

	<?php include('layout/foot.php') ?>


</body>

</html>

<header>
        <div class="header-content">
            <div class="header-content-inner">
                <img class="small-icon" src="img/logo.png"/>
                <br><br><br>
                <p class="large">
                BisaBelajar adalah tempat di mana kamu BisaBelajar apapun yang kamu mau.<br>
                Dengan sumber materi yang melimpah, kamu BisaBelajar secara cuma-cuma. <br>
                BisaBelajar adalah teman belajar terbaikmu!

                </p>
                <a href="#login" data-toggle="modal" data-target="#login" class="yellow-bg btn btn-primary btn-xl ">Mulai Belajar</a>
            </div>
        </div>
    </header>


    <section id="new-classes" class="class-bg black-bg ">


            <div class="container white-text">

                <div class="row green-bottom-border no-padding   ">
                    <div class=" col-lg-2  col-md-2 text-center">
                        <div class=" no-padding-top padding-narrow service-box">

                            <bold><h3>Kelas Terbaru</h3></bold>
                            <img class="icon-medium" src="img/new.png"/>
                        </div>
                    </div>
                    <div class="col-lg-10 tes text-center ">
                        <!-- Place somewhere in the <body> of your page -->
                        <div class="no-padding no-margin flexslider ">
                          <ul class="slides">
                           <li class="slider-content">
                            <a class="text-center new-info title" href="ekonomi.php">
                            <img  class="img-video-small" src="img/video/eco-1.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i>
                            </div>
                            <h5 class="white-text  bottom-border-small ">Konsumsi, Tabungan, dan Investasi</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="ekonomi.php">
                            <img class="img-video-small" src="img/video/eco-2.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i>
                            </div>
                            <h5 class="white-text  bottom-border-small">Kebijakan Pemerintah dalam Bidang Ekonomi</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="ekonomi.php">
                            <img class="img-video-small" src="img/video/eco-3.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Pasar Modal</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="ekonomi.php">
                            <img class="img-video-small" src="img/video/eco-4.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">APBN dan APBD</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="ekonomi.php">
                            <img class="img-video-small" src="img/video/eco-1.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Pengangguran dan Ketenagakerjaan</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="ekonomi.php">
                            <img class="img-video-small" src="img/video/eco-2.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Pendapatan Nasional</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                  
                              
                                <!-- items mirrored twice, total of 12 -->
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row no-padding">
                    <div class=" col-lg-2  col-md-2 text-center">
                        <div class=" no-padding-top padding-narrow service-box">

                            <bold><h3>Kelas Favorit</h3></bold>
                            <img class="icon-medium" src="img/fav.png"/>
                        </div>
                    </div>
                      <div class="col-lg-10 tes text-center">
                        <!-- Place somewhere in the <body> of your page -->
                        <div class="no-padding no-margin flexslider ">
                          <ul class="slides">
                           <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-3.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Elastisitas Permintaan dan Penawaran</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-4.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Permintaan, Penawaran, dan Harga Keseimbangan</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-1.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Kegiatan Konsumen dan Produsen</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-2.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Inflasi</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-3.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Sistem Ekonomi</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                          <li class="slider-content">
                            <a class="text-center new-info title" href="#">
                            <img class="img-video-small" src="img/video/eco-4.jpg" />
                            <div class="img-video-cover" href="ekonomi.php">
                            <i class="play fa fa-play-circle-o" href="ekonomi.php"></i></div>
                            <h5 class="white-text  bottom-border-small">Kebutuhan dan Kelangkaan</h5>
                            <yellow><h5 class="no-top-margin no-top-padding" >Ekonomi | SMA</h5>
                            </a>
                          </li>
                              
                                <!-- items mirrored twice, total of 12 -->
                            </ul>
                        </div>
                    </div>
                     

                </div>

          </div>

    </section>


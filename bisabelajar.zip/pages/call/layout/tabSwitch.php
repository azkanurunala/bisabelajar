

    <nav id="mainNav" class="text-center navbar tab-switch-default">
        <div class="container container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            
            <div class="col-lg-11 text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
 
                <ul class="nav navbar-nav">
                    <li class="tab-selected">
                        <a  class="link-tab" data-toggle="tab" href="#tentangKami"><h4 class="bold font-green">Tentang</h4></a>
                    </li>
                    <li class="tab-option">
                        <a  class="link-tab" data-toggle="tab" href="#timKami" ><h4 class="bold font-green">Tim Kami</h4></a>
                    </li >
                    <li class="tab-option" >
                        <a class="link-tab" data-toggle="tab" href="#kataMereka"><h4 class="bold font-green">Kata Mereka</h4></a>
                    </li>
                   
                </ul>
           
            </div>

            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
<div class="row">
	<a href="kelas.php">
		<h4 class="white-text ">
		<i class="fa fa-chevron-circle-left">
		</i>
			 Kembali ke <yellow>SMA</yellow>

		</h4>
	</a>
</div>
<div class="row">
	<ul class="list-title lists top-padding-narrow bottom-padding-narrow  no-top-margin  no-bottom-margin right-margin top-radius lists">
		<li class=""><a href="#" class="white-text"><h4><i class="fa fa-th-list"></i> Daftar Materi</a></h4></li>
	</ul>
	<ul class="grey-bg-2 lists padding-all no-top-margin right-margin  bottom-radius lists">
		
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Uang dan Perbankan</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Kebutuhan dan Kelangkaan</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Sistem Ekonomi</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Inflasi</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Kegiatan Konsumen dan Produsen</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Permintaan, Penawaran, dan Harga Keseimbangan</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Elastisitas Permintaan dan Penawaran</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Pendapatan Nasional</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Pengangguran dan Ketenagakerjaan</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> APBN dan APBD</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Pasar Modal</a></h5></li>
		<li class="bottom-border "><a href="#" class="font-green bold"><h5><i class="fa fa-play-circle-o"></i> Kebijakan Pemerintah dalam Bidang Ekonomi</a></h5></li>
		<li ><yellow><a href="#" ><yellow><h5><i class="fa fa-play"></i> Konsumsi, Tabungan, dan Investasi</h5></yellow></a></yellow></li>

	</ul>
</div>
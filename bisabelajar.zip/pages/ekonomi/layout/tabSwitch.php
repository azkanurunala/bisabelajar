
    <h3 class="text-center white-text "> Konsumsi, Tabungan, dan Investasi</h3>
    <div class="row">
    <nav id="mainNav" class="top-radius text-center navbar tab-switch-default" >

            <div   class=" row text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="col-lg-3">
                </div>
                <div class="col-lg-8">
                <ul class="nav navbar-nav" >
                    <li class="tab-selected">
                        <a  class="link-tab" data-toggle="tab" href="#video">
                       <h4 class="bold font-green"><i class="fa fa-play-circle-o"></i> Video</h4>
                        </a>
                    </li>

                    
                    <li class="tab-option">
                        <a  class="link-tab" data-toggle="tab" href="#latihan">
                        <h4 class="bold font-green"><i class="fa fa-pencil-square-o"></i> Latihan</h4>
                        </a>
                    </li>
                    <li class="tab-option">
                        <a  class="link-tab" data-toggle="tab" href="ringkasan">
                        <h4 class="bold font-green"><i class="fa fa-paper-plane"></i> Ringkasan</h4>
                        </a>
                    </li>

                </ul>
                </div>                

           
            </div>


        <!-- /.container-fluid -->
    </nav>
    </div>

    <div class="row tab tab-content text-center top-padding-narrow">
        <div id="video" class="tab-pane active">
            <div class="row">
                    <iframe allow-fullscreen="true" width="760" height="400" src="https://www.youtube.com/embed/JuyB7NO0EYY"  frameborder="0" allowfullscreen>
                    </iframe>
            </div>
            <?php include ('pages/ekonomi/layout/socmed.php') ?>
            <div class="row top-green-border bottom-green-border ">
                <div class="col-lg-3 text-left">
                    <a href="#"  class="yellow-outlined  padding-all-narrow btn btn-primary btn-xl ">
                    <i class="social-icon-2 fa fa-chevron-left"></i>SEBELUMNYA</a>
                </div>
                 <div class="col-lg-3 text-center">
                    <a href="#"  class="yell-bg  padding-all-narrow btn btn-primary btn-xl ">
                    IKUTI KELAS<i class="social-icon-2 fa fa-sign-in"></i></a>
                </div>
                 <div class="col-lg-3 text-center">
                    <a href="#"  class="red-bg padding-all-narrow btn btn-primary btn-xl ">
                    UNDUH VIDEO<i class="social-icon-2 fa fa-download"></i></a>
                </div>
                 <div class="col-lg-3 text-right">
                    <a href="#"  class="yellow-outlined  padding-all-narrow btn btn-primary btn-xl ">
                    SELANJUTNYA<i class="social-icon-2 fa fa-chevron-right"></i></a>
                </div>
            </div>
            <?php include ('pages/ekonomi/layout/comment.php') ?>


        </div>

        <div id="latihan" class="tab-pane">
            <div class="row text-center  padding-left padding-right">

                <div class="col-lg-12 latihan white-bg">
                    <yellow><h4 class="bold">Soal Nomor 1</h4></yellow>
                    <p  class="font-green text-left margin-small">
                    Isi soal nomer 1 Isi soal nomer 1 Isi soal nomer 1 Isi soal nomer 1
                    Isi soal nomer 1 Isi soal nomer 1 Isi soal nomer 1 Isi soal nomer 1
                    </p>
                </div>

            </div>

        </div>
        
        <div id="ringkasan" class="tab-pane">
        

        Ringkasan
        

        </div>
    </div>


   
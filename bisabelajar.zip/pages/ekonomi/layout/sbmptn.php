<div id="sbmptn" class="tab-pane">
<section>
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12">
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/mtk.png">
                        <h4 class="icon-link bold font-green">Matematika</h4>
                    </a>
                </div>
                 <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/ipa.png">
                        <h4 class="icon-link bold font-green">IPA</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/ips.png">
                        <h4 class="icon-link bold font-green">IPS</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/ind.png">
                        <h4 class="icon-link bold font-green">Indonesia</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/ing.png">
                        <h4 class="icon-link bold font-green">Inggris</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/pkn.png">
                        <h4 class="icon-link bold font-green">Kebudayaan</h4>
                    </a>
                </div>
            </div>
        </div>
    </div> 
   
</section>


            <div class="row ">
                
                <div class="col-lg-6 text-left">
                    <a href="#" class="share-btn fb-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-thumbs-up"></i>Like</a>

                    <a href="#" class="share-btn fb-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-share-alt"></i>Share</a>

                    <a href="#" class="tweet-btn twitter-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-twitter"></i>Tweet</a>
                </div>
         
                <div class="col-lg-6 text-right">
                    <a href="#" class="subscribe-btn fb-bg btn btn-primary btn-xl ">
                    <i class="social-icon fa fa-youtube"></i>Subscribe</a>
                </div>

            </div>
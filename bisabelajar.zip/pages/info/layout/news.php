<section >
    <div class="container">


        <div class="row">
            <div class="col-lg-8 ">
                            <p align="justify" >
                                <img  align="left" class="img-info-large right-margin-narrow" src="contents/gambar-1.png"/>
                               <?php include('contents/isi-1-1.txt');?>
                            </p>

            </div>
            <div class="all-border left-margin padding-small col-lg-3">

                <div class="bottom-border row text-center">
                    
                  <!--img class="icon" src="img/new_info.png"/-->
                  <yellow><h3 class="section-heading"><!--i class="fa fa-newspaper-o"></i--> Artikel Terkait</h3></yellow>

                        
                </div>

                <div class="padding-small row ">         

                            <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             <div class="bottom-border row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-3.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-3.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                            <div class="row">
                                    <a href="news-content.php">
                                    <h4 class=" title"> <?php include ('contents/judul-2.txt'); ?></h4>
                                    </a>
                                    <h5 class=" author "><?php include ('contents/penulis-2.txt'); ?></h5>
                                    <p class=" paragraph" >
                                       <?php include('contents/isi-2.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" >  BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>

                             </div>

                             
                             <!--div class="row">
                                <div class="no-padding col-lg-5">
                                  
                                    <a href="news-content.php">
                                    <img class="img-info-large" src="contents/gambar-4.png"/>
                                    </a>
                                  
                                </div>
                                <div class="no-padding col-lg-7">
                                    <a href="news-content.php">
                                    <h4 class=" no-padding new-info title"> <?php include ('contents/judul-4.txt'); ?></h4>
                                    </a>
                                    <h5 class=" new-info author "><?php include ('contents/penulis-4.txt'); ?></h5>
                                    <p class="new-info paragraph" >
                                       <?php include('contents/isi-4.txt');?>
                                        <a class="link-info top-margin right-margin  text-right " href="news-content.php" > BACA <span class="top-padding-narrow glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </p>
                                </div>
                             </div-->
                </div>

            </div>

        </div>
    </div> 
       

   
</section>
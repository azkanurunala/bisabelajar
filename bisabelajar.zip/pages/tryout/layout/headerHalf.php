      <section id="footer" class="header-half white-text">
       <div class="dark-bg-darker">
        <div class=" no-padding container">
            <div class="text-left">
                
                <div class="col-lg-1 text-left">
                     <img class="header-margin logo-small img-responsive" src="img/tryout_logo.png"/>
                </div>
                <div class="header-margin col-lg-11 text-left">
                     <h3>Tryout </h3>
                </div>
                
            </div>
        </div>
       </div>
    </section>

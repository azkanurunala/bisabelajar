<div id="timKami" class="tab-pane">
<section>
    <div class="container">
        <div class="row text-center">

          <h4 class="section-heading">Tim Kami</h4>
          <hr class="primary">
                
        </div>

        <div class="row text-center">
            <div class="col-lg-12">
                    
                    <div class="col-lg-4">

                        <div class="photo-container">
                            <img class="" src="photos/dikry.jpg"/>
                        </div>
                        <br>
                        <a href="#"><i class="fade-away fa fa-facebook fb social-icon"></i></a>
                        <a href="#"><i class="fade-away fa fa-twitter twitter social-icon"></i></a>
                        <h4 class="top-border-narrow bottom-border-narrow font-green bold">Dikry Paren   <yellow>CEO</yellow></h4>
                        <p>
                        An <bold>idealist</bold>, passionate in social activity, currently enrolled as a
                        student of Islamic Business, Universitas Indonesia
                        </p>
                
                    </div>

                    <div class="col-lg-4">

                        <div class="photo-container">
                            <img class="" src="photos/gandra.jpg"/>
                        </div>
                        <br>
                        <a href="#"><i class="fade-away fa fa-facebook fb social-icon"></i></a>
                        <a href="#"><i class="fade-away fa fa-twitter twitter social-icon"></i></a>
                        <h4 class="top-border-narrow bottom-border-narrow font-green bold">Gandra Braino   <yellow>CFO</yellow></h4>
                        <p>
                        An <bold>idealist</bold>, passionate in social activity, currently enrolled as a
                        student of Islamic Business, Universitas Indonesia
                        </p>
                
                    </div>

                    <div class="col-lg-4">

                        <div class="photo-container">
                            <img class="" src="photos/azka.jpg"/>
                        </div>
                        <br>
                        <a href="#"><i class="fade-away fa fa-facebook fb social-icon"></i></a>
                        <a href="#"><i class="fade-away fa fa-twitter twitter social-icon"></i></a>
                        <h4 class="top-border-narrow bottom-border-narrow font-green bold">Azka Nurun Ala   <yellow>CTO</yellow></h4>
                        <p>
                        An <bold>idealist</bold>, passionate in social activity, currently enrolled as a
                        student of Islamic Business, Universitas Indonesia
                        </p>
                
                    </div>



                        <!--p class="paragraph" >
                          <img align="left" class="right-margin bottom-margin-narrow img-info-large" src="img/logo.png"/>
                       
                          <?php include('contents/tentang/tentang-kami.txt');?>
                        </p-->
           
             

                    
            </div>

        </div>
    </div> 
   
</section>

<section id="kontributor" class="grey-bg">
    <div class="container">

        <div class="row text-center">

          <h4 class="section-heading">Kontributor</h4>
          <hr class="primary">
                
        </div>

        <div class="row text-center">



          <div class="col-lg-12 text-center">

                <div class="row">
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                     <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                    <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                     <div class="col-lg-2">
                        <img class="image-circle" src="photos/gandra.jpg">
                        <h4 class="font-green bold">Andi Rahmat</h4>
                        <h5 ><yellow>Kontributor Fisika SMA</yellow></h5>
                        <h5 class="bold">S1 Fisika UI</h5>
                    </div>
                </div>

          </div>
                
        </div>

        
    </div> 
   
</section>

<section id="compro">
  <div class="container">

    <div class="row text-center">

          <h4 class="section-heading">Partner Kami</h4>
          <hr class="primary">
                
    </div>

    <div class="row text-center">
        <div class="col-lg-12 text-center">
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
            <a href="#"><img class="partner-logo col-lg-2" src="img/logo_typo.png"></a>
        </div>
    </div>
   </div>
</section>
</div>
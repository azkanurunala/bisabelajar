<nav class="no-top-margin text-center navbar tab-switch-default" >
        <div class="container container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            
            <div   class="row text-center collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="col-lg-3">
                </div>
                <div class="col-lg-9">
                <ul class="nav navbar-nav" id="select" >
                    <li id="asd">
                        <a  class="link-tab" data-toggle="tab" href="#selectSD">
                        <img class="level-icon" src="img/class/level-sd.png">
                        <h4 class="bold font-green">SD</h4>
                        </a>
                    </li>

                    <li id="asmp">
                        <a  class="link-tab tab-option" data-toggle="tab" href="#selectSMP">
                        <img class="level-icon" src="img/class/level-smp.png">
                        <h4 class="bold font-green">SMP</h4>
                        </a>
                    </li>
                    <li id="asma">
                        <a  class="link-tab tab-option" data-toggle="tab" href="#selectSMA">
                        <img class="level-icon" src="img/class/level-sma.png">
                        <h4 class="bold font-green">SMA</h4>
                        </a>
                    </li>
                    <li id="aun">
                        <a  class="link-tab tab-option" data-toggle="tab" href="#selectUN">
                        <img class="level-icon" src="img/class/level-un.png">
                        <h4 class="bold font-green">UN</h4>
                        </a>
                    </li>
                    <li id="asbmptn">
                        <a  class="link-tab tab-option" data-toggle="tab" href="#selectSBMPTN">
                        <img class="level-icon" src="img/class/level-sbmptn.png">
                        <h4 class="bold font-green">SBMPTN</h4>
                        </a>
                    </li>
                    <li id="alain">
                        <a  class="link-tab tab-option " data-toggle="tab" href="#selectLain">
                        <img class="level-icon" src="img/class/level-lain.png">
                        <h4 class="bold font-green">Lainnya</h4>
                        </a>
                    </li>

                </ul>
                </div>                

           
            </div>

            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
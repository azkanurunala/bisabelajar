<div id="selectSMA" class="tab-pane"> 

 <?php include ('pages/class/layout/tabSwitch.php') ?>
<div >
<section class="narrow-section">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12">
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/mtk.png">
                        <h4 class="icon-link bold font-green">Matematika</h4>
                    </a>
                </div>
                 
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/ind.png">
                        <h4 class="icon-link bold font-green">Indonesia</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/ing.png">
                        <h4 class="icon-link bold font-green">Inggris</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/fis.png">
                        <h4 class="icon-link bold font-green">Fisika</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/kim.png">
                        <h4 class="icon-link bold font-green">Kimia</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/bio.png">
                        <h4 class="icon-link bold font-green">Biologi</h4>
                    </a>
                </div>
            </div>
            </div>

            <div class="row text-center">
            <div class="col-lg-12">
                <div class="col-lg-2">
                    <a href="ekonomi.php">
                        <img class="subject-icon" src="img/class/eko.png">
                    </a>
                    <a href="ekonomi.php">
                        <h4 class="icon-link bold font-green">Ekonomi</h4>
                    </a>
                </div>
                 <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/geo.png">
                        <h4 class="icon-link bold font-green">Geografi</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/sej.png">
                        <h4 class="icon-link bold font-green">Sejarah</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/sos.png">
                        <h4 class="icon-link bold font-green">Sosiologi</h4>
                    </a>
                </div>
                <div class="col-lg-2">
                    <a  class="link-tab" data-toggle="tab" href="#sbmptn">
                        <img class="subject-icon" src="img/class/pkn.png">
                        <h4 class="icon-link bold font-green">Kebudayaan</h4>
                    </a>
                </div>
            </div>
            </div>


    </div> 
   
</section>
</div>
</div>